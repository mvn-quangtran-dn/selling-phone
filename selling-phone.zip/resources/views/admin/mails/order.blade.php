<h1>Tên khách hàng: {{ $data['yourname'] }}</h1>
<p>Khách hàng đả Order sản phẩm: {{ $data_product['name'] }}</p>
<p>Với số lượng: {{ $data_product['quantity'] }}</p>
<p>Tổng thành tiền: {{ $data_product['total'] }}</p>