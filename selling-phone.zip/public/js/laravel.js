$(function() {
  function destroy() {
    alert("da click");
  }
  $('#destroy').click(function() {
      console.log("destroy");
  });
});